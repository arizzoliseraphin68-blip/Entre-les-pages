# Projet — Dédicaces manuscrites (React)

Ce site React collecte des photos de dédicaces manuscrites en français.

## Déploiement rapide

1. Ouvrez [vercel.com](https://vercel.com) ou [netlify.com](https://netlify.com).
2. Glissez ce dossier dans l'interface.
3. Le site sera disponible en ligne sous quelques secondes.

Adresse de réception des e-mails : arizzoliseraphin68@gmail.com.
