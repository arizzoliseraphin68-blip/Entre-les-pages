import React from "react";
import { createRoot } from "react-dom/client";
import SiteDedicationsFR from "./SiteDedicationsFR";

createRoot(document.getElementById("root")).render(<SiteDedicationsFR />);
